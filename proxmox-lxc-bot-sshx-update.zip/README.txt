SSHX feature update for Proxmox LXC Discord bot

Contents:
- bot.py: updated bot with SSHX and Stop SSHX buttons in .manage.

Install on the Proxmox host:
  cd /opt/proxmox-lxc-bot
  cp bot.py bot.py.backup-sshx
  # Upload/extract this ZIP into this directory, replacing bot.py only.
  systemctl restart proxmox-lxc-bot
  systemctl status proxmox-lxc-bot --no-pager

No Proxmox host reboot or Proxmox service restart is needed. This restarts only the Discord bot.

On first SSHX click for a running VPS, the bot installs SSHX inside that LXC (using the official sshx.io installer), starts a per-VMID systemd service, and DMs the owner the generated link. The dashboard also has Stop SSHX to end that session.

Security: SSHX URLs are bearer access links. The bot DMs only the recorded VPS owner. The session runs as root inside that VPS; anyone with the link can use the terminal. Do not post links publicly. SSHX traffic is relayed through sshx.io; see https://sshx.io/ and https://github.com/ekzhang/sshx.

The source's embedded fallback Proxmox token secret was removed. Keep your real token only in the existing .env file; this update does not include or replace .env or VPS data files.

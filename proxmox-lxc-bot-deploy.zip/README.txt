PROXMOX LXC DISCORD BOT - DEPLOYMENT BUNDLE

This bundle runs the bot as a systemd service. Starting/restarting this service
does NOT reboot or restart the Proxmox machine.

1) Copy this folder to the Proxmox host, then run:
   apt-get update
   apt-get install -y python3 python3-venv python3-pip
   mkdir -p /opt/proxmox-lxc-bot
   cp bot.py requirements.txt .env.example proxmox-lxc-bot.service /opt/proxmox-lxc-bot/
   cd /opt/proxmox-lxc-bot
   cp .env.example .env
   chmod 600 .env
   nano .env

2) Fill in DISCORD_TOKEN, PROXMOX_URL, PROXMOX_TOKEN_ID,
   PROXMOX_TOKEN_SECRET, PROXMOX_NODE, PROXMOX_STORAGE and PROXMOX_BRIDGE.
   Use a newly rotated Proxmox API token secret; the old secret was present
   in the uploaded source and should be treated as exposed.

3) Install dependencies and start only the bot service:
   python3 -m venv venv
   venv/bin/pip install --upgrade pip
   venv/bin/pip install -r requirements.txt
   install -m 644 proxmox-lxc-bot.service /etc/systemd/system/proxmox-lxc-bot.service
   systemctl daemon-reload
   systemctl enable --now proxmox-lxc-bot
   systemctl status proxmox-lxc-bot --no-pager
   journalctl -u proxmox-lxc-bot -n 80 --no-pager

Commands:
   systemctl restart proxmox-lxc-bot   # restarts only this bot
   systemctl stop proxmox-lxc-bot
   journalctl -u proxmox-lxc-bot -f

NOTE: The source defaults to Proxmox storage local-lvm and bridge vmbr1.
Confirm these exist on your host before using VPS creation commands.
